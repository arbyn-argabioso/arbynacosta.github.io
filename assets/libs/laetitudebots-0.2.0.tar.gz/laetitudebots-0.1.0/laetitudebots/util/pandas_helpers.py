# -*- encoding: utf-8 -*-

import pandas as pd
from pandas.tseries.frequencies import to_offset


def resample(ohlcv_df, freq, offset=None):
    if freq.endswith('m'):
        freq = freq.replace('m', 'T')

    # Convert offset to Pandas local DataOffset format
    offset = to_offset(offset)

    open_ = ohlcv_df.open.resample(freq, base=offset.n).first()
    close = ohlcv_df.close.resample(freq, base=offset.n).last()
    high = ohlcv_df.high.resample(freq, base=offset.n).max()
    low = ohlcv_df.low.resample(freq, base=offset.n).min()
    volume = ohlcv_df.volume.resample(freq, base=offset.n).sum()

    ohlcv_df = pd.DataFrame(
        {
            'open': open_,
            'high': high,
            'low': low,
            'close': close,
            'volume': volume,
            'datetime': close.index,
        }
    )

    ohlcv_df.set_index('datetime', inplace=True)

    return ohlcv_df
