from laetitudebots.factors.factors import Factors, Window
