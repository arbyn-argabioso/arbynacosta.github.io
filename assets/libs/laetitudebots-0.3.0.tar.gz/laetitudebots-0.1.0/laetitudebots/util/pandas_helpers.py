# -*- encoding: utf-8 -*-

import pandas as pd
from pandas.tseries.frequencies import to_offset


def resample(ohlcv_df, freq, offset=None):
    if freq.endswith('m'):
        freq = freq.replace('m', 'T')

    # Convert offset to Pandas local DataOffset format
    if offset.endswith('m'):
        long_offset = offset.replace('m', 'min')
    else:
        long_offset = offset
    print(long_offset)
    offset = to_offset(long_offset)

    open_ = ohlcv_df.open.resample(freq, loffset=long_offset).first()
    close = ohlcv_df.close.resample(freq, loffset=long_offset).last()
    high = ohlcv_df.high.resample(freq, loffset=long_offset).max()
    low = ohlcv_df.low.resample(freq, loffset=long_offset).min()
    volume = ohlcv_df.volume.resample(freq, loffset=long_offset).sum()

    ohlcv_df = pd.DataFrame(
        {
            'open': open_,
            'high': high,
            'low': low,
            'close': close,
            'volume': volume,
            'datetime': close.index,
        }
    )

    ohlcv_df.set_index('datetime', inplace=True)

    return ohlcv_df
