from laetitudebots.live import Live
from unittest.mock import MagicMock
import pytest


class TestConfigObj:
    data = {
        'context': {
            'assets': {
                'BTC/USDT': {
                    'orders': {},
                    'symbol_map': 'XBTUSD',
                    'exchange': 'binance'
                }
            },
            'is_shared_balance': True,
            'balance': 1
        },
        'time_interval': '1',
        'time_unit': 'd',
        'exchange': 'bitmex',
    }

    def save(self):
        pass


class TestLive(Live):
    """This is in order
    """
    def __init__(self, key):
        self.config_obj = TestConfigObj()
        self.config = self.config_obj.data
        self.context = self.config['context']
        self.exchange = MagicMock()


@pytest.fixture(scope='function')
def live():
    test_live = TestLive('test')
    test_live.set_strategy()

    return test_live

